'''
Hello World example script.
'''

import time

print("Hello, World!")
time.sleep(2)
print("This is a simple test script for the Script Launcher.")

